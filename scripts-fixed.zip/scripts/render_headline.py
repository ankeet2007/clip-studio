#!/usr/bin/env python3
"""
Render headline text (with emoji) to a transparent RGBA PNG file.

Usage: python3 render_headline.py '<json_params>'
JSON params: { text, font_path, font_size, line_spacing, max_chars, canvas_width, output_path }
Prints JSON to stdout: { "height": <int>, "lines": <int> }
"""
import sys
import json
from PIL import Image, ImageFont
from pilmoji import Pilmoji


def wrap_text(text: str, max_chars: int = 38) -> list:
    words = text.strip().split()
    lines = []
    current = ""
    for word in words:
        if not current:
            current = word
        elif len(current + " " + word) <= max_chars:
            current += " " + word
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or [text or ""]


def main():
    params = json.loads(sys.argv[1])
    text = params["text"]
    font_path = params["font_path"]
    font_size = int(params["font_size"])
    line_spacing = int(params["line_spacing"])
    max_chars = int(params.get("max_chars", 38))
    canvas_width = int(params["canvas_width"])
    output_path = params["output_path"]

    try:
        font = ImageFont.truetype(font_path, font_size)
    except Exception:
        font = ImageFont.load_default()

    lines = wrap_text(text, max_chars)
    line_height = font_size + line_spacing
    total_height = len(lines) * line_height + line_spacing  # bottom padding

    img = Image.new("RGBA", (canvas_width, total_height), (0, 0, 0, 0))

    y = 0
    with Pilmoji(img) as pilmoji:
        for line in lines:
            try:
                w, _ = pilmoji.getsize(line, font=font)
            except Exception:
                w = canvas_width // 2
            x = max(0, (canvas_width - w) // 2)
            pilmoji.text((x, y), line, font=font, fill=(0, 0, 0, 255))
            y += line_height

    img.save(output_path, "PNG")
    print(json.dumps({"height": total_height, "lines": len(lines)}))


if __name__ == "__main__":
    main()
